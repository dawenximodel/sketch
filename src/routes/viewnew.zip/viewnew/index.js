import { h, Component } from 'preact';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import classNames from 'classnames';
import { slope, onceTransitionEnd } from './helper';
import { setRuntimeVariable } from '~/actions';
import data from './index.json';
import s from './style.scss';

class View extends Component {
	constructor(props) {
		super(props);
		const { originData, time } = data;
		this.state = {
			originData,
			time,
			direction: 0 // -1上一个，1下一个，0
		};
		this.Width = window.innerWidth;
		this.Height = window.innerHeight;
		this.tranbox = null;
	}
		
	componentDidMount() {
		console.log(this.state.originData);
	}

	onTouchStart = (e) => {
		e.preventDefault();
		this.touchX = {
			start: null,
			end: null
		};
		this.touchY = {
			start: null,
			end: null
		};
		this.touchX.start = e.touches[0].screenX;
		this.touchY.start = e.touches[0].screenY;
	}

	onTouchMove = (e) => {
		this.touchX.end = e.touches[0].screenX;
		this.touchY.end = e.touches[0].screenY;
	}

	onTouchEnd = (e) => {
		const rate = slope(this.touchX.end - this.touchX.start, this.touchY.end - this.touchY.start, 30);

		if (rate !== -1) {
			return;
		}
		const { start, end } = this.touchX;
		if (start > end && start - end > 100) {
			this.handleNext(e);
		}
		if (start < end && end - start > 100) {
			this.handleLast();
		}
	}

	handleNext = () => {
		console.log('下一个');
		this.setState({
			direction: 1
		}, () => {
			onceTransitionEnd(this.tranbox)
				.then(() => {
					console.log('xxxx');
					this.handleResetPosition(true);
				});
		});
	}

	handleLast = () => {
		console.log('上一个', this.tranbox);
		this.setState({
			direction: -1
		}, () => {
			onceTransitionEnd(this.tranbox)
				.then(() => {
					console.log('xxxx');
					this.handleResetPosition();
				});
		});
	}

	handleResetPosition = (next) => {
		const { originData } = this.state;
		let oprationData = null;
		if (next){
			// console.log('1', originData.slice(1, originData.length));
			// console.log('2', originData[0]);
			oprationData=originData.slice(1, originData.length).concat(originData[0]);
			
		} else {
			oprationData=originData.slice(0, originData.length - 1).concat(originData[originData.length - 1]);
		}
		oprationData = JSON.parse(JSON.stringify(oprationData));
		console.log(oprationData);
		this.setState({
			direction: 0,
			originData: oprationData.concat(originData[0])
		});
	}

	handlePageStyle = () => {
		const { originData, direction } = this.state;
		const data = {
			left: Math.floor(originData.length/2) * this.Width * -1 - direction * this.Width,
			width: originData.length * this.Width
		};
		if (direction !== 0) {
			data['transition'] = 'left 500ms';
			data['-webkit-transition'] = 'left 500ms';
		}
		return data;
	}
		
	renderContent = () => {
		const { originData } = this.state;
		const result = [];
		originData.forEach((item, index) =>{
			const imageClassData = {};
			imageClassData[s.xlayout] = item.isY;
			imageClassData[s.ylayout] = item.isX;

			result.push(<div style={{width: this.Width, height: this.Height, left: index*this.Width}} className={s.page}  key={`${item.mdId}-${index}`}>
				<div className={s.content}>
					<img className={classNames(imageClassData)} src={`${this.props.requestPath.imageUrl}/${item.imgUrl}`}/>
				</div>
			</div>);
		});
		return <div
			ref={el => {this.tranbox = el;}}
			className={s.pages}
			style={this.handlePageStyle()}
			onTouchStart={this.onTouchStart}
			onTouchMove={this.onTouchMove}
			onTouchEnd={this.onTouchEnd}
		>
			{result}
		</div>;
	}
	

	render() {
		return (
			<div className={s.root}>
				{this.renderContent()}
			</div>
		);
	}
}

function mapStateToProps(state) {
	return state || {};
}


function mapDispatchToProps(dispatch){
	return bindActionCreators({ setStore: setRuntimeVariable }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(View);
